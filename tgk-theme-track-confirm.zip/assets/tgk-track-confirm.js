(function () {
  'use strict';
  if (window.__tgkTrackConfirm) return;
  window.__tgkTrackConfirm = true;

  var PROP_NAME = 'Track use acknowledged';
  var TRACK_RE = /track/i;
  var root = null;
  var pending = null;

  function ids(form) {
    return String(form.getAttribute('data-tgk-track-ids') || '')
      .split(',')
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
  }

  function variantId(form) {
    var input = form.querySelector('[name="id"]');
    return input ? String(input.value) : '';
  }

  function needsConfirm(form) {
    var list = ids(form);
    return list.length > 0 && list.indexOf(variantId(form)) !== -1;
  }

  function stamp() {
    var d = new Date();
    var pad = function (n) { return n < 10 ? '0' + n : String(n); };
    return 'Yes (' + d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()) +
      ' ' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ' UTC)';
  }

  function propInput(form) {
    return form.querySelector('input[data-tgk-track-prop]');
  }

  function setProp(form, on) {
    var el = propInput(form);
    if (on) {
      if (!el) {
        el = document.createElement('input');
        el.type = 'hidden';
        el.name = 'properties[' + PROP_NAME + ']';
        el.setAttribute('data-tgk-track-prop', '');
        form.appendChild(el);
      }
      el.value = stamp();
    } else if (el) {
      el.remove();
    }
  }

  function optionRadios(form) {
    if (!form.id) return [];
    return [].slice.call(document.querySelectorAll('input[type="radio"][form="' + form.id + '"]'));
  }

  function selectedTrackName(form) {
    var radios = optionRadios(form);
    for (var i = 0; i < radios.length; i++) {
      if (radios[i].checked && TRACK_RE.test(radios[i].value)) return radios[i].value;
    }
    var scope = form.closest('product-info') || form.closest('.product') || document;
    var sel = scope.querySelector('variant-selects select');
    if (sel && sel.selectedOptions[0] && TRACK_RE.test(sel.selectedOptions[0].text)) {
      return sel.selectedOptions[0].text.trim();
    }
    return 'Track';
  }

  function findStreet(form) {
    var radios = optionRadios(form);
    var checked = null;
    for (var i = 0; i < radios.length; i++) {
      if (radios[i].checked && TRACK_RE.test(radios[i].value)) { checked = radios[i]; break; }
    }
    if (checked) {
      var sibs = radios.filter(function (r) {
        return r !== checked && r.name === checked.name && !TRACK_RE.test(r.value) && !r.disabled;
      });
      var pick = sibs.filter(function (r) { return /street/i.test(r.value); })[0] || sibs[0];
      if (pick) return { label: pick.value, go: function () { pick.click(); } };
    }
    var scope = form.closest('product-info') || form.closest('.product') || document;
    var sel = scope.querySelector('variant-selects select');
    if (sel) {
      var opts = [].slice.call(sel.options).filter(function (o) { return !TRACK_RE.test(o.text) && !o.disabled; });
      var op = opts.filter(function (o) { return /street/i.test(o.text); })[0] || opts[0];
      if (op) {
        return {
          label: op.text.trim(),
          go: function () {
            sel.value = op.value;
            sel.dispatchEvent(new Event('change', { bubbles: true }));
          }
        };
      }
    }
    return null;
  }

  function isPreorder(form) {
    var btn = form.querySelector('[type="submit"]');
    return !!btn && /pre-?order/i.test(btn.textContent || '');
  }

  function build() {
    if (root) return root;
    root = document.createElement('div');
    root.className = 'tgk-tc';
    root.hidden = true;
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.setAttribute('aria-labelledby', 'tgk-tc-title');
    root.innerHTML =
      '<div class="tgk-tc__box">' +
        '<div class="tgk-tc__head"><h2 class="tgk-tc__title" id="tgk-tc-title">Confirm track version</h2></div>' +
        '<div class="tgk-tc__body">' +
          '<p class="tgk-tc__text"></p>' +
          '<div class="tgk-tc__btns">' +
            '<button type="button" class="tgk-tc__btn tgk-tc__btn--no"></button>' +
            '<button type="button" class="tgk-tc__btn tgk-tc__btn--yes"></button>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(root);

    root.addEventListener('focusin', function (e) { e.stopPropagation(); });
    root.addEventListener('keyup', function (e) { e.stopPropagation(); });
    root.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); close(true); return; }
      if (e.key === 'Tab') {
        var btns = root.querySelectorAll('button');
        var first = btns[0], last = btns[btns.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    root.addEventListener('click', function (e) {
      if (e.target === root) close(true);
    });
    root.querySelector('.tgk-tc__btn--no').addEventListener('click', function () {
      var p = pending;
      close(false);
      if (p && p.street) p.street.go();
      else if (p && p.opener && p.opener.focus) p.opener.focus();
    });
    root.querySelector('.tgk-tc__btn--yes').addEventListener('click', confirm);
    return root;
  }

  function open(form, submitter) {
    build();
    var street = findStreet(form);
    var name = selectedTrackName(form);
    var pre = isPreorder(form);

    var text = root.querySelector('.tgk-tc__text');
    text.textContent = '';
    text.appendChild(document.createTextNode("You're ordering the "));
    var strong = document.createElement('strong');
    strong.textContent = name;
    text.appendChild(strong);
    text.appendChild(document.createTextNode(' version. It is built for track use, and noise, vibration and harshness are highly likely on the street.'));

    root.querySelector('.tgk-tc__btn--no').textContent = street ? 'Switch to ' + street.label : 'Cancel';
    root.querySelector('.tgk-tc__btn--yes').textContent = pre ? 'I understand, pre-order' : 'I understand, add';

    pending = { form: form, submitter: submitter, street: street, opener: document.activeElement };
    root.hidden = false;
    document.documentElement.classList.add('tgk-tc-open');
    root.querySelector('.tgk-tc__btn--yes').focus();
  }

  function close(restoreFocus) {
    if (!root) return;
    root.hidden = true;
    document.documentElement.classList.remove('tgk-tc-open');
    var p = pending;
    pending = null;
    if (restoreFocus && p && p.opener && p.opener.focus) p.opener.focus();
    return p;
  }

  function confirm() {
    var p = pending;
    if (!p) return;
    close(false);
    var form = p.form;
    if (!form.isConnected) return;
    setProp(form, true);
    form.setAttribute('data-tgk-track-ok', '1');
    var btn = p.submitter && p.submitter.form === form ? p.submitter : form.querySelector('[type="submit"]');
    try {
      if (form.requestSubmit) form.requestSubmit(btn || undefined);
      else if (btn) btn.click();
      else form.submit();
    } catch (err) {
      if (btn) btn.click();
    }
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.nodeType !== 1 || !form.getAttribute || !ids(form).length) return;

    if (!needsConfirm(form)) {
      setProp(form, false);
      form.removeAttribute('data-tgk-track-ok');
      return;
    }
    if (form.getAttribute('data-tgk-track-ok') === '1') {
      form.removeAttribute('data-tgk-track-ok');
      setProp(form, true);
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
    open(form, e.submitter || null);
  }, true);

  function syncCheckout() {
    [].forEach.call(document.querySelectorAll('form[data-tgk-track-ids]'), function (form) {
      var host = form.closest('product-form');
      if (!host) return;
      var on = false;
      if (ids(form).length) {
        var radios = optionRadios(form);
        for (var i = 0; i < radios.length; i++) {
          if (radios[i].checked && TRACK_RE.test(radios[i].value)) { on = true; break; }
        }
        if (!on && radios.length === 0) {
          var scope = form.closest('product-info') || form.closest('.product') || document;
          var sel = scope.querySelector('variant-selects select');
          on = !!(sel && sel.selectedOptions[0] && TRACK_RE.test(sel.selectedOptions[0].text));
        }
      }
      if (on) host.setAttribute('data-tgk-track-on', '');
      else host.removeAttribute('data-tgk-track-on');
    });
  }

  document.addEventListener('change', function () {
    setTimeout(syncCheckout, 0);
    setTimeout(syncCheckout, 600);
  }, true);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', syncCheckout);
  else syncCheckout();
  setTimeout(syncCheckout, 1500);
})();
