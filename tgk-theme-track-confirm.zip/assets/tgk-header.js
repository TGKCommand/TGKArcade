/* TGK header and home hero.
   1. Keeps the My Garage chip in step with the saved vehicle: CSS draws the chip's second line
      from a custom property set here, and the garage button gets an accessible name that
      matches what is shown.
   2. Home hero card: when a vehicle is saved, the card shows a "Shopping for ..." summary
      instead of the finder (with "Change vehicle" to bring the finder back). The summary is
      displayed on desktop as a wide card and on phones and tablets as a slim bar.
   3. Phones and tablets (below 990px): the hero shows a thin "Find parts" bar. Its button opens
      a bottom sheet that holds the real finder (the finder is moved into the sheet while it is
      open and back afterwards, so its saved state and behaviour are untouched). */
(function () {
  'use strict';

  function fitment() {
    return window.TGKFitment && typeof window.TGKFitment.getVehicle === 'function' ? window.TGKFitment : null;
  }

  function vehicleText() {
    var F = fitment();
    var v = null;
    try {
      v = F ? F.getVehicle() : null;
    } catch (e) {
      v = null;
    }
    return v ? [v.year, v.make, v.model].filter(Boolean).join(' ') : '';
  }

  function nameGarageButton(box, text) {
    var btn = box.querySelector('.tgk-garage__btn');
    if (!btn) return;
    var name = 'My garage: ' + (text || 'add a vehicle');
    if (btn.getAttribute('aria-label') !== name) btn.setAttribute('aria-label', name);
  }

  function updateGarage() {
    var box = document.getElementById('tgk-garage');
    if (!box) return;
    var text = vehicleText();
    if (text) box.style.setProperty('--tgk-garage-vehicle', JSON.stringify(text));
    else box.style.removeProperty('--tgk-garage-vehicle');
    nameGarageButton(box, text);
  }

  /* The garage re-renders its button when the vehicle changes: re-apply the name then */
  function watchGarage() {
    var box = document.getElementById('tgk-garage');
    if (!box || box._tgkWatched || !window.MutationObserver) return;
    box._tgkWatched = true;
    new MutationObserver(function () {
      nameGarageButton(box, vehicleText());
    }).observe(box, { childList: true });
  }


  /* ---- Home hero card: saved-vehicle summary ---- */
  var CAR_ICON =
    '<svg class="tgk-hero-saved__icon" viewBox="0 0 512 512" aria-hidden="true" focusable="false"><path d="M92 228l46-106a40 40 0 0 1 37-24h162a40 40 0 0 1 37 24l46 106" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><rect x="48" y="228" width="416" height="152" rx="40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M120 304h44M348 304h44" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M108 380v44M404 380v44" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/></svg>';

  function heroBox() {
    return document.querySelector('.tgk-hero-banner .banner__box');
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function renderHeroSaved() {
    var box = heroBox();
    if (!box) return;
    var F = fitment();
    var v = null;
    try {
      v = F ? F.getVehicle() : null;
    } catch (e) {
      v = null;
    }
    var host = box.querySelector('.tgk-hero-saved');

    // No saved vehicle: back to the finder
    if (!v) {
      if (host && host.parentNode) {
        host.parentNode.removeChild(host);
        // the finder kept the old selections: start it over
        var reset = document.querySelector('#tgk-ymm .tgk-ymm__reset');
        if (reset) reset.click();
      }
      box.classList.remove('tgk-hero--saved');
      box.removeAttribute('data-tgk-changing');
      return;
    }

    if (!host) {
      host = el('div', 'tgk-hero-saved');
      // Inside the headline block, not beside it: the theme styles the card's direct children
      // by position, so adding a sibling would change spacing on phones and tablets.
      var head = box.querySelector('.tgk-rotate-head');
      var wrap = head && head.parentNode ? head.parentNode : box;
      wrap.insertBefore(host, wrap.firstChild);
      host.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('.tgk-hero-saved__change') : null;
        if (!btn) return;
        if (isMobile()) {
          openSheet(btn);
          return;
        }
        box.setAttribute('data-tgk-changing', '1');
        box.classList.remove('tgk-hero--saved');
        var first = document.querySelector('#tgk-ymm select:not([disabled])');
        if (first) first.focus();
      });
    }

    host.innerHTML = CAR_ICON;
    var text = el('div', 'tgk-hero-saved__text');
    text.appendChild(el('div', 'tgk-hero-saved__label', 'Shopping for'));
    text.appendChild(document.createTextNode(' ')); // keeps "Shopping for" and the vehicle apart for screen readers
    text.appendChild(el('div', 'tgk-hero-saved__vehicle', [v.year, v.make, v.model].filter(Boolean).join(' ')));
    var meta = el('div', 'tgk-hero-saved__meta');
    var detail = [v.engine, v.chassis].filter(Boolean).join(' \u00b7 ');
    if (detail) meta.appendChild(document.createTextNode(detail + ' \u00b7 '));
    var change = el('button', 'tgk-hero-saved__change');
    change.type = 'button';
    change.appendChild(el('span', 'tgk-lg', 'Change vehicle'));
    change.appendChild(el('span', 'tgk-sm', 'Change'));
    change.setAttribute('aria-label', 'Change vehicle');
    meta.appendChild(change);
    text.appendChild(meta);
    host.appendChild(text);
    var go = el('a', 'tgk-hero-saved__go');
    go.appendChild(el('span', 'tgk-lg', 'Shop parts that fit'));
    go.appendChild(el('span', 'tgk-sm', 'Shop parts'));
    go.setAttribute('aria-label', 'Shop parts that fit');
    try {
      go.href = typeof F.resultsUrl === 'function' ? F.resultsUrl(v) : '/pages/vehicle-parts';
    } catch (err) {
      go.href = '/pages/vehicle-parts';
    }
    host.appendChild(go);

    if (box.getAttribute('data-tgk-changing') !== '1') box.classList.add('tgk-hero--saved');
  }


  /* ---- Phones and tablets: thin bar + bottom sheet ---- */
  var MQ = window.matchMedia ? window.matchMedia('(max-width: 989.98px)') : null;
  var X_ICON =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var sheetEl = null;
  var scrimEl = null;
  var sheetBody = null;
  var closeBtn = null;
  var openBtn = null;
  var pickerHome = null;
  var lastFocus = null;
  var sheetOpen = false;

  function isMobile() {
    return !!(MQ && MQ.matches);
  }

  function buildSheet() {
    if (sheetEl) return;
    scrimEl = el('div', 'tgk-sheet-scrim');
    scrimEl.addEventListener('click', function () {
      closeSheet(true);
    });
    sheetEl = el('div', 'tgk-sheet');
    sheetEl.setAttribute('role', 'dialog');
    sheetEl.setAttribute('aria-modal', 'true');
    sheetEl.setAttribute('aria-labelledby', 'tgk-sheet-title');
    var grip = el('div', 'tgk-sheet__grip');
    grip.setAttribute('aria-hidden', 'true');
    var head = el('div', 'tgk-sheet__head');
    var title = el('div', 'tgk-sheet__title', 'Find parts for your vehicle');
    title.id = 'tgk-sheet-title';
    closeBtn = el('button', 'tgk-sheet__close');
    closeBtn.type = 'button';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.innerHTML = X_ICON;
    closeBtn.addEventListener('click', function () {
      closeSheet(true);
    });
    head.appendChild(title);
    head.appendChild(closeBtn);
    sheetBody = el('div', 'tgk-sheet__body');
    sheetEl.appendChild(grip);
    sheetEl.appendChild(head);
    sheetEl.appendChild(sheetBody);
    sheetEl.addEventListener('keydown', onSheetKey);
    document.body.appendChild(scrimEl);
    document.body.appendChild(sheetEl);
  }

  function setExpanded(on) {
    if (openBtn) openBtn.setAttribute('aria-expanded', on ? 'true' : 'false');
  }

  function onSheetKey(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      closeSheet(true);
      return;
    }
    if (e.key !== 'Tab') return;
    var items = [].slice
      .call(sheetEl.querySelectorAll('select:not([disabled]), button:not([disabled]), a[href]'))
      .filter(function (n) {
        return n.offsetParent !== null;
      });
    if (!items.length) return;
    var first = items[0];
    var last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  function onDocKey(e) {
    if (e.key === 'Escape' && sheetOpen) closeSheet(true);
  }

  function openSheet(trigger) {
    if (!isMobile() || sheetOpen) return;
    var node = document.getElementById('tgk-ymm');
    if (!node) return;
    buildSheet();
    if (node.parentNode !== sheetBody) pickerHome = node.parentNode;
    sheetBody.appendChild(node);
    lastFocus = trigger || document.activeElement;
    sheetOpen = true;
    document.addEventListener('keydown', onDocKey);
    scrimEl.classList.add('is-open');
    sheetEl.classList.add('is-open');
    document.documentElement.classList.add('tgk-sheet-lock');
    setExpanded(true);
    requestAnimationFrame(function () {
      var f = sheetEl.querySelector('select:not([disabled])') || closeBtn;
      if (f) f.focus();
    });
  }

  function restorePicker() {
    var node = document.getElementById('tgk-ymm');
    if (node && pickerHome && sheetBody && node.parentNode === sheetBody) pickerHome.appendChild(node);
  }

  function closeSheet(restoreFocus) {
    if (!sheetOpen) return;
    sheetOpen = false;
    document.removeEventListener('keydown', onDocKey);
    if (sheetEl) sheetEl.classList.remove('is-open');
    if (scrimEl) scrimEl.classList.remove('is-open');
    document.documentElement.classList.remove('tgk-sheet-lock');
    setExpanded(false);
    // give the finder back to the page once the sheet has slid away
    setTimeout(function () {
      if (!sheetOpen) restorePicker();
    }, 300);
    if (restoreFocus && lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function ensureOpenButton() {
    var head = document.querySelector('.tgk-hero-banner .tgk-rotate-head');
    if (!head || !head.parentNode) return;
    if (openBtn && document.body.contains(openBtn)) return;
    openBtn = el('button', 'tgk-sheet-open', 'Choose car');
    openBtn.type = 'button';
    openBtn.setAttribute('aria-haspopup', 'dialog');
    openBtn.setAttribute('aria-expanded', sheetOpen ? 'true' : 'false');
    openBtn.addEventListener('click', function () {
      openSheet(openBtn);
    });
    head.parentNode.insertBefore(openBtn, head.nextSibling);
    // tapping the empty part of the bar opens it too
    var box = heroBox();
    if (box && !box._tgkTap) {
      box._tgkTap = true;
      box.addEventListener('click', function (e) {
        if (!isMobile() || box.classList.contains('tgk-hero--saved')) return;
        if (e.target.closest && e.target.closest('a, button, select, input')) return;
        openSheet(openBtn);
      });
    }
  }

  function removeOpenButton() {
    if (openBtn && openBtn.parentNode) openBtn.parentNode.removeChild(openBtn);
    openBtn = null;
  }

  function syncMobile() {
    if (isMobile()) {
      ensureOpenButton();
    } else {
      closeSheet(false);
      restorePicker();
      removeOpenButton();
    }
  }

  if (MQ) {
    if (MQ.addEventListener) MQ.addEventListener('change', syncMobile);
    else if (MQ.addListener) MQ.addListener(syncMobile);
  }

  /* Hero slideshow: after the first photo change, switch on the longer cross-dissolve */
  function watchHeroSlides() {
    var car = document.querySelector('.tgk-hero-banner .tgk-hero-car');
    if (!car || car._tgkCine || !window.MutationObserver) return;
    car._tgkCine = true;
    new MutationObserver(function (list) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].oldValue !== null) {
          car.classList.add('is-cine');
          return;
        }
      }
    }).observe(car, { attributes: true, attributeFilter: ['data-index'], attributeOldValue: true });
  }

  // Footer links that open a section of the Support page. They are matched by their wording, so
  // the menu in Shopify admin can stay as it is. Add a line here to send another link to a section.
  var SUPPORT_PAGE = 'pages/support';
  var FOOTER_TO_SUPPORT = {
    'returns & exchanges': 'warranty',
    'returns and exchanges': 'warranty',
    'dealer application': 'wholesale',
    'rebate submission': 'rebate'
  };

  function linkFooterToSupport() {
    var root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';
    var links = document.querySelectorAll('footer a[href]');
    for (var i = 0; i < links.length; i++) {
      var name = (links[i].textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      var section = FOOTER_TO_SUPPORT[name];
      if (section) links[i].setAttribute('href', root + SUPPORT_PAGE + '#' + section);
    }
  }

  // Catalog on phones: each department is a compact row that opens to its sub-categories, one at a time.
  var deptPhone = window.matchMedia('(max-width: 749.98px)');

  function setDept(d, on) {
    d.classList.toggle('is-open', on);
    var nm = d.querySelector('.tgk-dept__name');
    if (nm) nm.setAttribute('aria-expanded', on ? 'true' : 'false');
  }

  function syncDepts() {
    var depts = document.querySelectorAll('.tgk-catalog .tgk-dept:not(.tgk-dept--skel)');
    for (var i = 0; i < depts.length; i++) {
      var nm = depts[i].querySelector('.tgk-dept__name');
      if (!nm) continue;
      if (deptPhone.matches) {
        nm.setAttribute('role', 'button');
        nm.setAttribute('aria-expanded', depts[i].classList.contains('is-open') ? 'true' : 'false');
      } else {
        nm.removeAttribute('role');
        nm.removeAttribute('aria-expanded');
        depts[i].classList.remove('is-open');
      }
    }
  }

  document.addEventListener('click', function (e) {
    if (!deptPhone.matches || !e.target.closest) return;
    var d = e.target.closest('.tgk-catalog .tgk-dept:not(.tgk-dept--skel)');
    // links inside the opened list (and "Shop all") work normally
    if (!d || e.target.closest('.tgk-dept__subs, .tgk-dept__all')) return;
    e.preventDefault();
    var open = !d.classList.contains('is-open');
    var others = document.querySelectorAll('.tgk-catalog .tgk-dept.is-open');
    for (var i = 0; i < others.length; i++) setDept(others[i], false);
    setDept(d, open);
  });

  // a link made into a button should answer the Space key too
  document.addEventListener('keydown', function (e) {
    if (e.key !== ' ' || !deptPhone.matches || !e.target.closest) return;
    var nm = e.target.closest('.tgk-catalog .tgk-dept__name');
    if (nm) {
      e.preventDefault();
      nm.click();
    }
  });

  if (deptPhone.addEventListener) deptPhone.addEventListener('change', syncDepts);
  else if (deptPhone.addListener) deptPhone.addListener(syncDepts);

  // the department cards are drawn by tgk-fitment.js after its data arrives: set each one up as it appears
  function watchDepts() {
    syncDepts();
    var list = document.querySelector('.tgk-catalog [data-list]');
    if (!list || list.__tgkWatch || !window.MutationObserver) return;
    list.__tgkWatch = true;
    new MutationObserver(syncDepts).observe(list, { childList: true });
  }


  // Shop by platform (Catalog): Make, then Platform, then a button straight to that platform's page.
  // The list comes from the page (a JSON block built from the collections that use the vehicle template).
  // Every label is kept SHORT on purpose: phone pickers wrap long text into tall rows, and a long name must never run past the button.
  function initPlatformPickers() {
    [].forEach.call(document.querySelectorAll('[data-tgk-sp]'), function (root) {
      if (root.__tgkSp) return;
      var dataEl = root.querySelector('[data-sp-data]'), items = [];
      try { items = JSON.parse(dataEl ? dataEl.textContent : '[]') || []; } catch (e) { items = []; }
      items = items.filter(function (i) { return i && i.url && i.name; });
      if (!items.length) return;
      var mkSel = root.querySelector('[data-sp-make]'), plSel = root.querySelector('[data-sp-plat]'), go = root.querySelector('[data-sp-go]'), goT = root.querySelector('[data-sp-go-t]');
      var mkV = root.querySelector('[data-sp-make-v]'), plV = root.querySelector('[data-sp-plat-v]'), cnt = root.querySelector('[data-sp-count]');
      if (!mkSel || !plSel || !go || !goT || !mkV || !plV) return;
      root.__tgkSp = true;
      var byMake = {};
      items.forEach(function (i) { var m = String(i.make || 'Other'); (byMake[m] = byMake[m] || []).push(i); });
      var makes = Object.keys(byMake).sort(function (a, b) { if (a === 'Other') return 1; if (b === 'Other') return -1; return a.localeCompare(b); });
      Object.keys(byMake).forEach(function (m) {
        byMake[m].sort(function (a, b) { return (b.count || 0) - (a.count || 0) || String(a.name).localeCompare(String(b.name)); });
      });
      function opt(value, text) { var o = document.createElement('option'); o.value = value; o.textContent = text; return o; }
      function clip(t, n) { t = String(t); return t.length > n ? t.slice(0, n - 1).replace(/\s+$/, '') + '\u2026' : t; }
      // "Audi B9 (A4, S4, A5, S5) performance parts" -> "B9": drop the bracketed models, the words "performance parts" and the make
      function shortName(i) {
        var mk = String(i.make || ''), nm = String(i.name || '');
        nm = nm.replace(/\([^)]*\)/g, ' ').replace(/\bperformance\b/ig, ' ').replace(/\bparts\b/ig, ' ').replace(/\s+/g, ' ').trim();
        if (mk && mk !== 'Other' && nm.toLowerCase().indexOf(mk.toLowerCase()) === 0) nm = nm.slice(mk.length).replace(/^[\s\-\u2013:]+/, '').trim();
        return nm || String(i.name);
      }
      function fullName(i) {
        var mk = String(i.make || ''), nm = shortName(i);
        return (mk && mk !== 'Other' && nm.toLowerCase().indexOf(mk.toLowerCase()) !== 0) ? mk + ' ' + nm : nm;
      }
      // one short line, like the car finder's lists: "B9 \u2014 A4 S4 A5 S5 (2017\u20132024)"; the models are left out if they would make it long
      function label(i) {
        var base = clip(shortName(i), 18), yrs = i.years ? ' (' + i.years + ')' : '';
        var mods = String(i.models || '').replace(/\s*\u00b7\s*/g, ' ').replace(/\s+/g, ' ').trim();
        var t = base + (mods ? ' \u2014 ' + mods : '') + yrs;
        if (t.length > 36) t = base + yrs;
        return clip(t, 40);
      }
      function show(sel, v) {
        var o = sel.options[sel.selectedIndex];
        v.textContent = o ? o.textContent : '';
        v.classList.toggle('is-ph', !sel.value);
        sel.parentNode.classList.toggle('is-off', sel.disabled);
      }
      function off() {
        go.removeAttribute('href');
        go.setAttribute('aria-disabled', 'true');
        go.setAttribute('tabindex', '-1');
        goT.textContent = 'View parts';
      }
      function on(i) {
        go.setAttribute('href', i.url);
        go.removeAttribute('aria-disabled');
        go.removeAttribute('tabindex');
        goT.textContent = 'View ' + clip(fullName(i), 30) + ' parts';
      }
      function fillPlatforms() {
        var list = byMake[mkSel.value] || [];
        plSel.innerHTML = '';
        plSel.appendChild(opt('', list.length ? 'Choose a platform' : 'Platform'));
        list.forEach(function (i, n) { plSel.appendChild(opt(String(n), label(i))); });
        plSel.disabled = !list.length;
        off();
        if (list.length === 1) { plSel.value = '0'; on(list[0]); }
        show(mkSel, mkV);
        show(plSel, plV);
      }
      function chosen() { var list = byMake[mkSel.value] || []; return plSel.value === '' ? null : list[+plSel.value]; }
      makes.forEach(function (m) { mkSel.appendChild(opt(m, m + ' (' + byMake[m].length + ')')); });
      if (cnt) cnt.textContent = items.length + ' platform' + (items.length === 1 ? '' : 's');
      mkSel.addEventListener('change', fillPlatforms);
      plSel.addEventListener('change', function () { var i = chosen(); if (i) on(i); else off(); show(plSel, plV); });
      go.addEventListener('click', function (e) { if (go.getAttribute('aria-disabled') === 'true') e.preventDefault(); });
      // coming back with the Back button: start clean rather than showing a half-restored choice
      window.addEventListener('pageshow', function (e) { if (e.persisted) { mkSel.value = ''; fillPlatforms(); } });
      show(mkSel, mkV);
      show(plSel, plV);
      root.hidden = false;
    });
  }


  // Product cards: the vendor is already shown on its own line, so a title that starts with it ("TGK Motorsport Audi 4.0T Air Intake")
  // drops the repeat ("Audi 4.0T Air Intake"). The full title stays as the link's tooltip and for screen readers. Safe to run any number of times.
  function trimCardTitles(root) {
    [].forEach.call((root || document).querySelectorAll('.product-card .card__heading a'), function (a) {
      if (a.getAttribute('data-tgk-trim')) return;
      var card = a.closest('.product-card'), v = card && card.querySelector('.product-vendor');
      var vendor = v ? v.textContent.replace(/\s+/g, ' ').trim() : '', full = a.textContent.replace(/\s+/g, ' ').trim();
      a.setAttribute('data-tgk-trim', '1');
      if (!vendor || full.length <= vendor.length || full.toLowerCase().indexOf(vendor.toLowerCase()) !== 0) return;
      var rest = full.slice(vendor.length).replace(/^[\s\-\u2013\u2014:|]+/, '');
      if (rest.length < 3) return;
      if (!a.getAttribute('title')) a.setAttribute('title', full);
      if (!a.getAttribute('aria-label')) a.setAttribute('aria-label', full);
      a.textContent = rest;
    });
  }

  // Cards arrive after the page loads (the collection grid when you filter or sort, "Recently viewed", related products): trim the new ones too.
  // Only a change that adds a product card makes it look again, so cart and menu updates cost nothing.
  function watchCardTitles() {
    trimCardTitles(document);
    if (document.__tgkTrimWatch || !window.MutationObserver) return;
    document.__tgkTrimWatch = true;
    var t = null;
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var add = muts[i].addedNodes;
        for (var j = 0; j < add.length; j++) {
          var n = add[j];
          if (n.nodeType === 1 && ((n.matches && n.matches('.product-card, .product-card-wrapper')) || (n.querySelector && n.querySelector('.product-card')))) {
            clearTimeout(t);
            t = setTimeout(function () { trimCardTitles(document); }, 30);
            return;
          }
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  // The footer's "All platforms" link points at the closed list on the Catalog page: open it when you arrive.
  function initAllPlatforms() {
    function list() { return document.getElementById('all-platforms'); }
    function open() {
      var d = list();
      if (d && d.tagName === 'DETAILS' && location.hash === '#all-platforms') d.open = true;
    }
    // When the list is opened, the make of the shopper's saved car opens with it
    function openMyMake() {
      var d = list();
      if (!d || d.querySelector('.tgk-spall__mk[open]')) return;
      var v = null;
      try { v = JSON.parse(localStorage.getItem('tgk_vehicle') || 'null'); } catch (e) {}
      var m = v && v.make ? String(v.make).toLowerCase() : '';
      if (!m) return;
      [].some.call(d.querySelectorAll('.tgk-spall__mk'), function (x) {
        if (x.getAttribute('data-make') !== m) return false;
        x.open = true;
        return true;
      });
    }
    // Only one make is open at a time ("toggle" does not bubble, so listen while it travels down)
    if (!document.__tgkSpall) {
      document.__tgkSpall = true;
      document.addEventListener('toggle', function (e) {
        var t = e.target;
        if (!t || !t.classList) return;
        if (t.id === 'all-platforms' && t.open) openMyMake();
        else if (t.classList.contains('tgk-spall__mk') && t.open) {
          [].forEach.call(t.parentNode.children, function (s) { if (s !== t && s.open) s.open = false; });
        }
      }, true);
    }
    open();
    window.addEventListener('hashchange', open);
  }

  // Phones, product page: a slim Add to cart bar once the real buy button has scrolled out of view. It presses the real button, so variants,
  // stock checks and the cart drawer all behave exactly as before. It steps aside near the footer, and the back-to-top
  // button rides above it (the --tgk-float-lift variable).
  function initStickyAtc() {
    var bar = document.querySelector('[data-tgk-satc]');
    if (!bar || bar.__tgkSatc) return;
    var main = document.querySelector('product-form button[name="add"], product-form .product-form__submit');
    if (!main) return;
    bar.__tgkSatc = true;
    var btn = bar.querySelector('[data-satc-btn]'), priceEl = bar.querySelector('[data-satc-price]');
    var phone = window.matchMedia ? window.matchMedia('(max-width: 749.98px)') : { matches: false };
    var pastMain = false, atFooter = false, shown = false;

    function render() {
      var on = !!(phone.matches && pastMain && !atFooter);
      if (on === shown) return;
      shown = on;
      bar.classList.toggle('is-on', on);
      document.documentElement.style.setProperty('--tgk-float-lift', on ? bar.offsetHeight + 'px' : '0px');
    }
    function syncButton() {
      var off = main.disabled || main.getAttribute('aria-disabled') === 'true';
      var label = (main.textContent || '').replace(/\s+/g, ' ').trim();
      btn.disabled = off;
      if (label) btn.textContent = label;
      bar.classList.toggle('is-loading', main.classList.contains('loading'));
    }
    function syncPrice() {
      var box = document.querySelector('.product__info-container .price, .product__info-wrapper .price');
      if (!box || !priceEl) return;
      var el = box.querySelector('.price-item--sale:not(.price-item--last)') || box.querySelector('.price-item--last') || box.querySelector('.price-item--regular');
      var t = el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
      if (t) priceEl.textContent = t;
    }
    btn.addEventListener('click', function () { if (!main.disabled) main.click(); });

    if (window.IntersectionObserver) {
      new IntersectionObserver(function (es) {
        var e = es[es.length - 1];
        pastMain = !e.isIntersecting && e.boundingClientRect.top < 0;
        render();
      }).observe(main);
      var foot = document.querySelector('footer');
      if (foot) new IntersectionObserver(function (es) { atFooter = es[es.length - 1].isIntersecting; render(); }).observe(foot);
    }
    if (window.MutationObserver) {
      new MutationObserver(syncButton).observe(main, { attributes: true, childList: true, characterData: true, subtree: true });
      var pb = document.querySelector('.product__info-container .price, .product__info-wrapper .price');
      if (pb) new MutationObserver(syncPrice).observe(pb, { childList: true, subtree: true, characterData: true });
    }
    if (phone.addEventListener) phone.addEventListener('change', render);
    syncButton();
    syncPrice();
  }

  function init() {
    updateGarage();
    watchGarage();
    renderHeroSaved();
    watchHeroSlides();
    syncMobile();
    linkFooterToSupport();
    watchDepts();
    initPlatformPickers();
    initAllPlatforms();
    initStickyAtc();
    watchCardTitles();
  }

  document.addEventListener('tgk:vehicle', function () {
    updateGarage();
    renderHeroSaved();
  });
  document.addEventListener('tgk:vehicles', updateGarage);

  // Theme editor: the header section re-renders, so start over
  document.addEventListener('shopify:section:load', function () {
    setTimeout(init, 0);
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  // The garage button is drawn by tgk-fitment.js on DOMContentLoaded; name it once it exists
  window.addEventListener('load', init);
})();
