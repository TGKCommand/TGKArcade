if (!customElements.get('country-selector')) {
  class CountrySelector extends HTMLElement {
    constructor() {
      super();
      this.provinceElement = this.querySelector('.js-shipping-province');
      this.countryElement = this.querySelector('.js-shipping-country');
      this.provinceWrapper = this.querySelector('.js-province-container');
      window.initScriptOnDemand(this, this.init.bind(this));
    }

    init() {
      CountrySelector.selectOption(this.countryElement, this.countryElement.dataset.default);

      this.updateProvinceOptions();

      if (this.provinceElement.dataset.default && this.provinceElement.options.length > 0) {
        CountrySelector.selectOption(this.provinceElement, this.provinceElement.dataset.default);
      }

      this.countryElement.addEventListener('change', this.updateProvinceOptions.bind(this));
    }

    /**
     * Updates the province/state options based on selected country.
     */
    updateProvinceOptions() {
      const selectedCountry = this.countryElement.options[this.countryElement.selectedIndex];
      const provinceList = JSON.parse(selectedCountry.dataset.provinces);

      // Clear existing options in the province field.
      Array.from(this.provinceElement.options).forEach((option) => option.remove());

      if (provinceList && provinceList.length === 0) {
        this.provinceWrapper.hidden = true;
      } else {
        provinceList.forEach((province) => {
          const provinceOption = document.createElement('option');
          [provinceOption.value, provinceOption.innerHTML] = province;
          this.provinceElement.appendChild(provinceOption);
        });

        this.provinceWrapper.hidden = false;
      }
    }

    /**
     * Sets the selected option of a <select> element.
     * @param {Element} dropdown - Country or province <select> element.
     * @param {string} value - The value to be selected in the dropdown.
     */
    static selectOption(dropdown, value) {
      Array.from(dropdown.options).forEach((option, index) => {
        if (option.value === value || option.innerHTML === value) {
          dropdown.selectedIndex = index;
        }
      });
    }
  }

  customElements.define('country-selector', CountrySelector);
}

if (!customElements.get('shipping-calculator')) {
  class ShippingCalculator extends HTMLElement {
    constructor() {
      super();
      this.submitButton = this.querySelector('button');
      this.shippingForm = this.querySelector('form');
      this.shippingForm.addEventListener('submit', this.processFormSubmit.bind(this));
    }

    initialize() {
      this.countryField = this.querySelector('.js-shipping-country');
      this.provinceField = this.querySelector('.js-shipping-province');
      this.cityField = this.querySelector('.js-city-input');
      this.addressField = this.querySelector('.js-address-input');
      this.zipField = this.querySelector('.js-zip-input');
      this.ratesDisplay = this.querySelector('.js-shipping-rate');
      this.errorDisplay = this.querySelector('.js-shipping-error');
      this.isInitialized = true;
    }

    /**
     * Handles the form submission for calculating shipping rates.
     * @param {object} event - The submit event object.
     */
    async processFormSubmit(event) {
      event.preventDefault();
      if (!this.isInitialized) this.initialize();

      this.errorDisplay.hidden = true;
      this.ratesDisplay.hidden = true;
      this.submitButton.disabled = true;

      this.submitButton.setAttribute('aria-disabled', true);
      this.submitButton.classList.add('loading');
      this.submitButton.querySelector('.loading__spinner').classList.remove('hidden', 'spinning-complete');

      // TGK: send only what the shopper filled in, properly encoded. The original line sent the TEXT "undefined" as the city and
      // street when those boxes are hidden, which a carrier can reject for an international address (no rates at all).
      const fields = {
        zip: this.zipField.value,
        country: this.countryField.value,
        province: this.provinceField.hidden || (this.provinceField.closest('.js-province-container') || {}).hidden ? '' : this.provinceField.value,
        city: this.cityField ? this.cityField.value : '',
        address1: this.addressField ? this.addressField.value : ''
      };
      const queryParams = Object.keys(fields)
        .filter((key) => String(fields[key] || '').trim() !== '')
        .map((key) => `shipping_address[${key}]=${encodeURIComponent(String(fields[key]).trim())}`)
        .join('&');

      try {
        const response = await fetch(`${window.routes.cart_url}/shipping_rates.json?${queryParams}`, { headers: { Accept: 'application/json' } });
        let resultData = null;
        try { resultData = await response.json(); } catch (parseError) { resultData = null; }  // an HTML / empty reply

        if (response.ok && resultData) {
          this.displayRates(resultData);
        } else {
          this.displayErrors(resultData, response.status);
        }
      } catch (error) {
        console.error(error); // eslint-disable-line
        this.displayErrors(null, 0);  // network problem: tell the shopper, do not just stop the spinner
      } finally {
        this.submitButton.disabled = false;
        this.submitButton.setAttribute('aria-disabled', false);
        this.submitButton.classList.remove('loading');
        this.submitButton.querySelector('.loading__spinner').classList.add('hidden', 'spinning-complete');
      }
    }

    /**
     * Displays the available shipping rates.
     * @param {object} data - The response data from the shipping API.
     */
    displayRates(data) {
      const headingElement = this.ratesDisplay.querySelector('.js-shipping-rate-heading');
      const textElement = this.ratesDisplay.querySelector('.js-shipping-rate-text');
      textElement.innerHTML = '';

      if (data.shipping_rates && data.shipping_rates.length) {
        const headingText = data.shipping_rates.length === 1 ? 'singleRate' : 'multipleRates';
        let rateOptions = '';

        data.shipping_rates.forEach((rate) => {
          let formattedPrice = theme.settings.moneyWithCurrencyFormat.replace(/\{\{\s*(\w+)\s*\}\}/, rate.price);
          if (rate.currency) {  // TGK: show the rate in the currency it was quoted in
            try { formattedPrice = new Intl.NumberFormat(undefined, { style: 'currency', currency: rate.currency }).format(parseFloat(rate.price)); } catch (formatError) { /* keep the theme format */ }
          }
          rateOptions += `<li>${ShippingCalculator.esc(rate.presentment_name || rate.name)}: ${formattedPrice}</li>`;
        });

        headingElement.textContent = window.strings.cart.shippingCalculator[headingText];
        textElement.innerHTML = `<ul class="mt-1 t5">${rateOptions}</ul>`;
        headingElement.hidden = false;
      } else {
        headingElement.hidden = true;
        textElement.innerHTML = window.strings.cart.shippingCalculator.noRates;
      }

      this.ratesDisplay.hidden = false;
    }

    /**
     * Displays errors related to shipping rate retrieval.
     * @param {object} data - The error data from the shipping API.
     */
    displayErrors(data, status) {
      const LABELS = { zip: 'Postal code', province: 'State / province', country: 'Country', city: 'City', address1: 'Address', base: '' };
      let errorMessages = '';

      if (data && typeof data === 'object') {
        Object.keys(data).forEach((key) => {
          const value = Array.isArray(data[key]) ? data[key].join(', ') : String(data[key]);
          const label = Object.prototype.hasOwnProperty.call(LABELS, key) ? LABELS[key] : key;
          errorMessages += `<li>${label ? `<strong>${ShippingCalculator.esc(label)}:</strong> ` : ''}${ShippingCalculator.esc(value)}</li>`;
        });
      }
      if (!errorMessages) {  // no readable reason came back (timeout, server error, offline)
        errorMessages = `<li>We couldn't get a shipping rate just now${status ? ` (error ${status})` : ''}. Please try again.</li>`;
      }
      errorMessages += '<li>Not sure what to enter? You can skip this calculator - your exact UPS rate is shown at checkout, or contact us and we will quote you directly.</li>';

      this.errorDisplay.querySelector('.js-shipping-error-content').innerHTML = `<ul class="mt-1 t5">${errorMessages}</ul>`;
      this.errorDisplay.hidden = false;
    }

    static esc(text) {
      return String(text == null ? '' : text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
  }

  customElements.define('shipping-calculator', ShippingCalculator);
}
