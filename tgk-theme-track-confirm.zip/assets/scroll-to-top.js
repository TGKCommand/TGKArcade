if (!customElements.get('scroll-to-top-button')) {
  class ScrollToTopButton extends HTMLElement {
    constructor() {
      super();

      // Toggle the 'reveal' class based on scroll position.
      // On phones it only shows while you scroll UP (and hides again after a moment), so it does not sit on top of product buttons
      // while you browse down the page.
      const phoneQuery = window.matchMedia ? window.matchMedia('(max-width: 749.98px)') : null;
      let lastY = window.scrollY;
      let idleTimer = null;
      this.classList.toggle('reveal', !(phoneQuery && phoneQuery.matches) && window.scrollY > window.innerHeight);

      window.addEventListener('scroll', () => {
        requestAnimationFrame(() => {
          const y = window.scrollY;
          const deep = y > window.innerHeight;
          if (!(phoneQuery && phoneQuery.matches)) {
            this.classList.toggle('reveal', deep);
            lastY = y;
            return;
          }
          if (!deep || y > lastY + 4) {
            this.classList.remove('reveal');
          } else if (y < lastY - 4) {
            this.classList.add('reveal');
            clearTimeout(idleTimer);
            idleTimer = setTimeout(() => this.classList.remove('reveal'), 2500);
          }
          if (Math.abs(y - lastY) > 4) lastY = y;
        });
      }, {passive: true});

      // Handle click event
      this.addEventListener('click', () => {
        this.scrollToTop();
      });

      // Handle Enter key event
      this.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          this.scrollToTop();
        }
      });
    }

    // Generic scroll-to-top function
    scrollToTop() {
      window.scrollTo({top: 0, behavior: 'smooth'});

      // Set a timeout to wait for the scroll to finish before focusing
      setTimeout(() => {
        document.querySelector('.skip-to-content-link')?.focus()
      }, 700);
    }
  }

  customElements.define('scroll-to-top-button', ScrollToTopButton);
}
