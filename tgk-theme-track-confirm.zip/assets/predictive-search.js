customElements.whenDefined('search-form').then(() => {
  class PredictiveSearch extends SearchForm {
    constructor() {
      super();
      this.cachedResults = {};
      this.predictiveSearchResults = this.querySelector('[data-predictive-search]');
      this.allPredictiveSearchInstances = document.querySelectorAll('predictive-search');
      this.isOpen = false;
      this.abortController = new AbortController();
      this.searchTerm = '';
      this.productTypes = this.querySelector('.js-product-types');
      window.initScriptOnDemand(this, this.init.bind(this));
    }

    init() {
      this.setupEventListeners();
    }

    setupEventListeners() {
      this.input.form.addEventListener('submit', this.onFormSubmit.bind(this));

      this.input.addEventListener('focus', this.onFocus.bind(this));
      this.input.addEventListener('input', debounce((event) => { this.onChange(event);}, 300).bind(this));
      this.productTypes?.addEventListener('change', this.onChange.bind(this));
      this.addEventListener('keyup', this.onKeyup.bind(this));
      this.addEventListener('keydown', this.onKeydown.bind(this));
      if (this.closest('.template-search__search') || this.closest('.header__search-bar')) {
        this.addEventListener('focusout', this.onFocusOut.bind(this));
      }

      this.addEventListener('click', (event) => {
        if (event.target.matches('.inline-search__close-button') || event.target.closest('.inline-search__close-button')) {
          this.onFormReset();
          this.close();
          document.activeElement.blur();
          setTimeout(() => { document.activeElement.blur(); }, 500);
        }
      });
    }

    getQuery() {
      return this.input.value.trim();
    }

    onChange() {
      const newSearchTerm = this.getQuery();
      if (!this.searchTerm || !newSearchTerm.startsWith(this.searchTerm)) {
        this.querySelector('#predictive-search-results-groups-wrapper')?.classList.add('opacity-20');
      }

      if(newSearchTerm.length === 0){
        // Remove the results when they are no longer relevant for the new search term
        // so they don't show up when the dropdown opens again
        this.querySelector('#predictive-search-results-groups-wrapper')?.remove();
      }

      this.searchTerm = newSearchTerm;

      if (!this.searchTerm.length) {
        this.close(true);
        return;
      }

      this.getSearchResults(this.searchTerm);
    }

    onFormSubmit(event) {
      if (!this.getQuery().length || this.querySelector('[aria-selected="true"] a')) event.preventDefault();
    }

    onFormReset(event) {
      super.onFormReset(event);
      if (super.shouldResetForm()) {
        this.searchTerm = '';
        this.abortController.abort();
        this.abortController = new AbortController();
        this.closeResults(true);
      }
    }

    onFocus() {
      const currentSearchTerm = this.getQuery();

      if (window.visualViewport) {
        setTimeout(() => {
          document.documentElement.style.setProperty('--bvh', `${window.visualViewport.height}px`);
        }, 100);

        setTimeout(() => {
          document.documentElement.style.setProperty('--bvh', `${window.visualViewport.height}px`);
        }, 500);
      }

      if (!currentSearchTerm.length) return;

      if (this.searchTerm !== currentSearchTerm) {
        // Search term was changed from other search input, treat it as a user change
        this.onChange();
      } else if (this.getAttribute('results') === 'true') {
        this.open();
      } else {
        this.getSearchResults(this.searchTerm);
      }
    }

    onFocusOut() {
      setTimeout(() => {
        if (!this.contains(document.activeElement)) {
          this.close();
        }
      });
    }

    onKeyup(event) {
      if (!this.getQuery().length) this.close(true);
      event.preventDefault();

      switch (event.code) {
        case 'ArrowUp':
          this.switchOption('up');
          break;
        case 'ArrowDown':
          this.switchOption('down');
          break;
        case 'Enter':
          this.selectOption();
          break;
      }
    }

    onKeydown(event) {
      // Prevent the cursor from moving in the input when using the up and down arrow keys
      if (event.code === 'ArrowUp' || event.code === 'ArrowDown') {
        event.preventDefault();
      }
    }

    switchOption(direction) {
      if (!this.getAttribute('open')) return;

      const moveUp = direction === 'up';
      const selectedElement = this.querySelector('[aria-selected="true"]');

      // Filter out hidden elements (duplicated page and article resources) thanks
      // to this https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/offsetParent
      const allVisibleElements = Array.from(this.querySelectorAll('li, button.predictive-search__item')).filter(
          (element) => element.offsetParent !== null
      );
      let activeElementIndex = 0;

      if (moveUp && !selectedElement) return;

      let selectedElementIndex = -1;
      let i = 0;

      while (selectedElementIndex === -1 && i <= allVisibleElements.length) {
        if (allVisibleElements[i] === selectedElement) {
          selectedElementIndex = i;
        }
        i++;
      }

      this.statusElement.textContent = '';

      if (!moveUp && selectedElement) {
        activeElementIndex = selectedElementIndex === allVisibleElements.length - 1 ? 0 : selectedElementIndex + 1;
      } else if (moveUp) {
        activeElementIndex = selectedElementIndex === 0 ? allVisibleElements.length - 1 : selectedElementIndex - 1;
      }

      if (activeElementIndex === selectedElementIndex) return;

      const activeElement = allVisibleElements[activeElementIndex];

      activeElement.setAttribute('aria-selected', true);
      if (selectedElement) selectedElement.setAttribute('aria-selected', false);

      this.input.setAttribute('aria-activedescendant', activeElement.id);
    }

    selectOption() {
      const selectedOption = this.querySelector('[aria-selected="true"] a, button[aria-selected="true"]');

      if (selectedOption) selectedOption.click();
    }

    getSearchResults(searchTerm) {
      const formData = new FormData(document.querySelector('.predictive_search_form') || document.querySelector('.predictive_search_page_form'));
      const params = new URLSearchParams(formData);

      if (this.productTypes && this.productTypes.value.length > 0) {
        searchTerm = `product_type:${this.productTypes.value} AND ${searchTerm}`;
      }

      params.set('q', searchTerm);

      const urlParams = params.toString();
      const queryKey = urlParams.toLowerCase();

      this.setLiveRegionLoadingState();

      if (this.cachedResults[queryKey]) {
        this.renderSearchResults(this.cachedResults[queryKey]);
        return;
      }

      fetch(`${routes.predictive_search_url}?${urlParams}`, {
        signal: this.abortController.signal,
      })
          .then((response) => {
            if (!response.ok) {
              var error = new Error(response.status);
              this.close();
              throw error;
            }

            return response.text();
          })
          .then((text) => {
            const resultsMarkup = new DOMParser()
                .parseFromString(text, 'text/html')
                .querySelector('#shopify-section-predictive-search').innerHTML;
            // TGK Motorsport products always go first: ask Shopify once more for TGK only and merge it in
            return this.putTgkFirst(resultsMarkup, params, searchTerm).then((markup) => {
              // Save bandwidth keeping the cache in all instances synced
              this.allPredictiveSearchInstances.forEach((predictiveSearchInstance) => {
                predictiveSearchInstance.cachedResults[queryKey] = markup;
              });
              this.renderSearchResults(markup);
            });
          })
          .catch((error) => {
            if (error?.code === 20) {
              // Code 20 means the call was aborted
              return;
            }
            this.close();
            throw error;
          });
    }

    // Shopify only returns its top few matches (8 here), so a TGK product ranked lower never shows up on its own.
    // This asks for TGK-only matches as well, puts them first, and keeps the dropdown the same length. If anything goes
    // wrong (no TGK matches, a failed request) the normal dropdown is shown untouched.
    putTgkFirst(markup, params, term) {
      const vendor = ((window.TGK_FIT_CONFIG && window.TGK_FIT_CONFIG.tgkVendor) || 'TGK Motorsport').replace(/"/g, '');
      if (!vendor || /(^|\s)vendor:/i.test(term)) return Promise.resolve(markup);

      const box = document.createElement('div');
      box.innerHTML = markup;
      const list = box.querySelector('#predictive-search-results-products-list');
      if (!list || !list.children.length) return Promise.resolve(markup);

      const tgkParams = new URLSearchParams(params);
      tgkParams.set('q', 'vendor:"' + vendor + '" AND ' + term);
      tgkParams.set('resources[type]', 'product');

      const handleOf = (li) => {
        const a = li.querySelector('a[href*="/products/"]');
        const m = a && a.getAttribute('href').match(/\/products\/([^\/?#]+)/);
        return m ? decodeURIComponent(m[1]) : null;
      };
      const vendorOf = (li) => {
        const v = li.querySelector('.predictive-search__item-vendor');
        return v ? v.textContent.trim().toLowerCase() : '';
      };

      return fetch(`${routes.predictive_search_url}?${tgkParams.toString()}`, { signal: this.abortController.signal })
        .then((response) => (response.ok ? response.text() : ''))
        .then((text) => {
          if (!text) return markup;
          const doc = new DOMParser().parseFromString(text, 'text/html');
          const tgkList = doc.querySelector('#predictive-search-results-products-list');
          if (!tgkList || !tgkList.children.length) return markup;

          const tgk = [].slice.call(tgkList.children).filter((li) => handleOf(li));
          if (!tgk.length) return markup;
          const seen = {};
          tgk.forEach((li) => { seen[handleOf(li)] = 1; });

          const rest = [].slice.call(list.children).filter((li) => !seen[handleOf(li)]);
          const moreTgk = rest.filter((li) => vendorOf(li) === vendor.toLowerCase());
          const others = rest.filter((li) => vendorOf(li) !== vendor.toLowerCase());
          const total = list.children.length;
          const merged = tgk.concat(moreTgk).concat(others).slice(0, total);

          merged.forEach((li, i) => {
            li.id = 'predictive-search-option-product-' + (i + 1);
            if (seen[handleOf(li)] || vendorOf(li) === vendor.toLowerCase()) li.setAttribute('data-tgk', '1');
          });
          while (list.firstChild) list.removeChild(list.firstChild);
          merged.forEach((li) => list.appendChild(li));
          return box.innerHTML;
        })
        .catch((error) => {
          if (error && error.code === 20) throw error; // the search was cancelled by newer typing
          return markup;
        });
    }

    setLiveRegionLoadingState() {
      this.statusElement = this.statusElement || this.querySelector('.predictive-search-status');
      this.loadingText = this.loadingText || this.getAttribute('data-loading-text');

      this.setLiveRegionText(this.loadingText);
      this.setAttribute('loading', true);
    }

    setLiveRegionText(statusText) {
      this.statusElement.setAttribute('aria-hidden', 'false');
      this.statusElement.textContent = statusText;

      setTimeout(() => {
        this.statusElement.setAttribute('aria-hidden', 'true');
      }, 1000);
    }

    renderSearchResults(resultsMarkup) {
      this.querySelector('.search-suggestions')?.classList.add('hidden');

      this.predictiveSearchResults.innerHTML = resultsMarkup;
      this.setAttribute('results', true);

      this.setLiveRegionResults();
      this.open();
      if (window.updateViewportSize) window.updateViewportSize();
    }

    setLiveRegionResults() {
      this.removeAttribute('loading');
      this.setLiveRegionText(this.querySelector('[data-predictive-search-live-region-count-value]').textContent);
    }

    open() {
      this.setAttribute('open', true);
      this.input.setAttribute('aria-expanded', true);
      this.isOpen = true;
    }

    close(clearSearchTerm = false) {
      this.closeResults(clearSearchTerm);
      this.isOpen = false;
    }

    closeResults(clearSearchTerm = false) {
      if (clearSearchTerm) {
        this.input.value = '';
      }
      this.querySelector('.search-suggestions')?.classList.remove('hidden');
      const selected = this.querySelector('[aria-selected="true"]');

      if (selected) selected.setAttribute('aria-selected', false);

      this.input.setAttribute('aria-activedescendant', '');
      this.removeAttribute('loading');
      this.removeAttribute('open');
      this.removeAttribute('results');
      this.input.setAttribute('aria-expanded', false);
      this.predictiveSearchResults.removeAttribute('style');
    }
  }

  customElements.define('predictive-search', PredictiveSearch);
});